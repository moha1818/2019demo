CREATE FUNCTION `_nextval`(`n` VARCHAR(50))
  RETURNS INT(11)
begin  -- 类似oracle sequence.nextval 方法
declare _cur int;  
set _cur=(select current_value from sys_sequence where name= n);  
update sys_sequence  
 set current_value = _cur + increment  
 where name=n ;  
return _cur;  
end
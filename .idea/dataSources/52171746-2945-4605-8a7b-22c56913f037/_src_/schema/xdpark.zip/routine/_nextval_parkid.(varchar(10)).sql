CREATE FUNCTION `_nextval_parkid`(`n` VARCHAR(10))
  RETURNS INT(4)
begin  -- 类似oracle sequence.nextval 方法
declare _cur int;  
set _cur=(select current_value from sys_seq_parkid where name= n);  
update sys_seq_parkid 
 set current_value = _cur + increment  
 where name=n ;  
return _cur;  
end